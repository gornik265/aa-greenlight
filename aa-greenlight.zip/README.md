# aa-greenlight
A plugin for AllianceAuth that lets users send Discord alerts using buttons.
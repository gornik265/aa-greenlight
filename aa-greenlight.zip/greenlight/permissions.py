# Use Django permissions framework to control access
